#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import RPi.GPIO as GPIO
import time

# =========================
# 1) 引脚定义（按你的接线修改）
# =========================

# 超声波 HC-SR04
TRIG_PIN = 23
ECHO_PIN = 24

# 红外循迹（3路：左/中/右）
IR_LEFT_PIN = 17
IR_MID_PIN = 27
IR_RIGHT_PIN = 22

# 电机驱动 L298N
# 左电机
IN1 = 5
IN2 = 6
ENA = 12   # PWM

# 右电机
IN3 = 13
IN4 = 19
ENB = 18   # PWM

# =========================
# 2) 参数配置
# =========================

# 距离阈值（cm），小于此值触发避障
OBSTACLE_DISTANCE_CM = 20.0

# 巡线速度 / 转向速度 (0~100)
SPEED_FORWARD = 45
SPEED_TURN = 40
SPEED_AVOID = 45

# 红外传感器逻辑：
# 常见模块：检测到黑线输出 LOW(0)，白底输出 HIGH(1)
# 如果你的模块相反，改成 False
LINE_IS_BLACK = True

# 主循环周期
LOOP_DELAY = 0.02

# =========================
# 3) GPIO 初始化
# =========================

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

# 超声波
GPIO.setup(TRIG_PIN, GPIO.OUT)
GPIO.setup(ECHO_PIN, GPIO.IN)
GPIO.output(TRIG_PIN, False)

# 红外输入
GPIO.setup(IR_LEFT_PIN, GPIO.IN)
GPIO.setup(IR_MID_PIN, GPIO.IN)
GPIO.setup(IR_RIGHT_PIN, GPIO.IN)

# 电机输出
for pin in [IN1, IN2, IN3, IN4, ENA, ENB]:
    GPIO.setup(pin, GPIO.OUT)

pwm_left = GPIO.PWM(ENA, 1000)   # 1kHz
pwm_right = GPIO.PWM(ENB, 1000)
pwm_left.start(0)
pwm_right.start(0)

# =========================
# 4) 底层运动函数
# =========================

def set_motor(left_speed, right_speed, left_forward=True, right_forward=True):
    left_speed = max(0, min(100, left_speed))
    right_speed = max(0, min(100, right_speed))

    # 左轮方向
    GPIO.output(IN1, GPIO.HIGH if left_forward else GPIO.LOW)
    GPIO.output(IN2, GPIO.LOW if left_forward else GPIO.HIGH)

    # 右轮方向
    GPIO.output(IN3, GPIO.HIGH if right_forward else GPIO.LOW)
    GPIO.output(IN4, GPIO.LOW if right_forward else GPIO.HIGH)

    pwm_left.ChangeDutyCycle(left_speed)
    pwm_right.ChangeDutyCycle(right_speed)


def forward(speed=SPEED_FORWARD):
    set_motor(speed, speed, True, True)


def backward(speed=SPEED_AVOID):
    set_motor(speed, speed, False, False)


def turn_left(speed=SPEED_TURN):
    # 左轮慢/停，右轮前进（简单左转）
    set_motor(0, speed, True, True)


def turn_right(speed=SPEED_TURN):
    # 右轮慢/停，左轮前进（简单右转）
    set_motor(speed, 0, True, True)


def spin_left(speed=SPEED_TURN):
    # 原地左旋
    set_motor(speed, speed, False, True)


def spin_right(speed=SPEED_TURN):
    # 原地右旋
    set_motor(speed, speed, True, False)


def stop():
    pwm_left.ChangeDutyCycle(0)
    pwm_right.ChangeDutyCycle(0)
    GPIO.output(IN1, GPIO.LOW)
    GPIO.output(IN2, GPIO.LOW)
    GPIO.output(IN3, GPIO.LOW)
    GPIO.output(IN4, GPIO.LOW)

# =========================
# 5) 传感器读取
# =========================

def read_distance_cm(timeout=0.03):
    # 发送 10us 脉冲
    GPIO.output(TRIG_PIN, True)
    time.sleep(0.00001)
    GPIO.output(TRIG_PIN, False)

    start_wait = time.time()
    while GPIO.input(ECHO_PIN) == 0:
        pulse_start = time.time()
        if pulse_start - start_wait > timeout:
            return 999.0  # 超时视作无障碍

    start_wait = time.time()
    while GPIO.input(ECHO_PIN) == 1:
        pulse_end = time.time()
        if pulse_end - start_wait > timeout:
            return 999.0

    pulse_duration = pulse_end - pulse_start
    distance = pulse_duration * 34300 / 2  # cm
    return distance


def read_ir_raw():
    l = GPIO.input(IR_LEFT_PIN)
    m = GPIO.input(IR_MID_PIN)
    r = GPIO.input(IR_RIGHT_PIN)
    return l, m, r


def on_line(val):
    # 根据模块逻辑转换为“是否检测到线”
    if LINE_IS_BLACK:
        return val == 0
    return val == 1


def read_line_state():
    l_raw, m_raw, r_raw = read_ir_raw()
    l = on_line(l_raw)
    m = on_line(m_raw)
    r = on_line(r_raw)
    return l, m, r

# =========================
# 6) 行为策略
# =========================

def line_follow_step():
    l, m, r = read_line_state()

    # 典型三路循迹策略
    if m and not l and not r:
        forward(SPEED_FORWARD)
    elif l and not r:
        turn_left(SPEED_TURN)
    elif r and not l:
        turn_right(SPEED_TURN)
    elif l and m and r:
        # 十字路口或全黑，保持前进
        forward(SPEED_FORWARD)
    elif not l and not m and not r:
        # 丢线：可改成原地找线
        spin_right(SPEED_TURN)
    else:
        # 其他过渡状态，轻微前进
        forward(SPEED_FORWARD)


def avoid_obstacle_step():
    # 一个简单避障动作序列：停 -> 后退 -> 右转
    stop()
    time.sleep(0.08)

    backward(SPEED_AVOID)
    time.sleep(0.20)

    spin_right(SPEED_AVOID)
    time.sleep(0.28)

    stop()
    time.sleep(0.05)

# =========================
# 7) 主循环
# =========================

def main():
    print("程序启动：循迹 + 超声波避障")
    time.sleep(0.5)

    try:
        while True:
            dist = read_distance_cm()

            if dist < OBSTACLE_DISTANCE_CM:
                avoid_obstacle_step()
            else:
                line_follow_step()

            time.sleep(LOOP_DELAY)

    except KeyboardInterrupt:
        print("\n手动停止")
    finally:
        stop()
        pwm_left.stop()
        pwm_right.stop()
        GPIO.cleanup()
        print("GPIO 已清理，程序退出")


if __name__ == "__main__":
    main()