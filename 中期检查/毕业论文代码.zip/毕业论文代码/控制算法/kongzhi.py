"""
智能小车 MPC 控制示例（二维路径跟踪）

依赖:
	pip install numpy cvxpy matplotlib

说明:
1) 使用运动学自行车模型 (kinematic bicycle model)
2) 每个控制周期对模型在线线性化，构建线性时变 MPC
3) 目标是跟踪给定轨迹，输出速度 v 与转角 delta
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

import cvxpy as cp
import matplotlib.pyplot as plt
import numpy as np


@dataclass
class MPCConfig:
	dt: float = 0.1
	horizon: int = 12
	wheel_base: float = 0.26

	# 状态: [x, y, yaw, v]
	# 控制: [a, delta]
	q_x: float = 20.0
	q_y: float = 20.0
	q_yaw: float = 5.0
	q_v: float = 1.0
	r_a: float = 0.3
	r_delta: float = 1.0
	rd_a: float = 0.2
	rd_delta: float = 1.5

	max_steer: float = np.deg2rad(30.0)
	max_accel: float = 2.0
	max_speed: float = 3.0
	min_speed: float = 0.0


def normalize_angle(angle: float) -> float:
	return (angle + np.pi) % (2.0 * np.pi) - np.pi


def kinematic_step(
	state: np.ndarray,
	control: np.ndarray,
	dt: float,
	wheel_base: float,
) -> np.ndarray:
	x, y, yaw, v = state
	a, delta = control

	x_next = x + v * np.cos(yaw) * dt
	y_next = y + v * np.sin(yaw) * dt
	yaw_next = yaw + (v / wheel_base) * np.tan(delta) * dt
	v_next = v + a * dt

	return np.array([x_next, y_next, normalize_angle(yaw_next), v_next], dtype=float)


def linearize_dynamics(
	state_ref: np.ndarray,
	control_ref: np.ndarray,
	cfg: MPCConfig,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
	"""
	对离散运动学模型在参考点 (state_ref, control_ref) 处一阶线性化:
		x_{k+1} ≈ A x_k + B u_k + c
	"""
	x, y, yaw, v = state_ref
	a, delta = control_ref
	dt = cfg.dt
	l = cfg.wheel_base

	A = np.eye(4)
	A[0, 2] = -v * np.sin(yaw) * dt
	A[0, 3] = np.cos(yaw) * dt
	A[1, 2] = v * np.cos(yaw) * dt
	A[1, 3] = np.sin(yaw) * dt
	A[2, 3] = (np.tan(delta) / l) * dt

	B = np.zeros((4, 2))
	B[2, 1] = (v / l) * (1.0 / (np.cos(delta) ** 2)) * dt
	B[3, 0] = dt

	f_ref = kinematic_step(state_ref, control_ref, dt, l)
	c = f_ref - A @ state_ref - B @ control_ref
	c[2] = normalize_angle(c[2])

	return A, B, c


def nearest_index(path_xy: np.ndarray, x: float, y: float, last_idx: int = 0) -> int:
	search_end = min(last_idx + 80, len(path_xy))
	segment = path_xy[last_idx:search_end]
	d2 = (segment[:, 0] - x) ** 2 + (segment[:, 1] - y) ** 2
	return last_idx + int(np.argmin(d2))


def build_reference_trajectory(
	path: np.ndarray,
	start_idx: int,
	horizon: int,
) -> np.ndarray:
	"""返回形状为 (4, horizon+1) 的参考状态序列 [x, y, yaw, v]^T。"""
	ref = np.zeros((4, horizon + 1))
	n = len(path)
	for k in range(horizon + 1):
		idx = min(start_idx + k, n - 1)
		ref[:, k] = path[idx]
	return ref


class LinearMPC:
	def __init__(self, cfg: MPCConfig):
		self.cfg = cfg
		self.Q = np.diag([cfg.q_x, cfg.q_y, cfg.q_yaw, cfg.q_v])
		self.R = np.diag([cfg.r_a, cfg.r_delta])
		self.Rd = np.diag([cfg.rd_a, cfg.rd_delta])

	def solve(
		self,
		x0: np.ndarray,
		x_ref: np.ndarray,
		u_ref: np.ndarray,
	) -> Tuple[np.ndarray, np.ndarray]:
		n_x = 4
		n_u = 2
		n = self.cfg.horizon

		x = cp.Variable((n_x, n + 1))
		u = cp.Variable((n_u, n))

		cost = 0.0
		constraints = [x[:, 0] == x0]

		for k in range(n):
			A, B, c = linearize_dynamics(x_ref[:, k], u_ref[:, k], self.cfg)

			constraints += [x[:, k + 1] == A @ x[:, k] + B @ u[:, k] + c]
			constraints += [u[0, k] <= self.cfg.max_accel, u[0, k] >= -self.cfg.max_accel]
			constraints += [u[1, k] <= self.cfg.max_steer, u[1, k] >= -self.cfg.max_steer]
			constraints += [x[3, k] <= self.cfg.max_speed, x[3, k] >= self.cfg.min_speed]

			e = x[:, k] - x_ref[:, k]
			cost += cp.quad_form(e, self.Q)
			cost += cp.quad_form(u[:, k] - u_ref[:, k], self.R)

			if k < n - 1:
				cost += cp.quad_form(u[:, k + 1] - u[:, k], self.Rd)

		e_terminal = x[:, n] - x_ref[:, n]
		cost += cp.quad_form(e_terminal, self.Q)

		prob = cp.Problem(cp.Minimize(cost), constraints)
		prob.solve(solver=cp.OSQP, warm_start=True, verbose=False)

		if prob.status not in (cp.OPTIMAL, cp.OPTIMAL_INACCURATE):
			raise RuntimeError(f"MPC 求解失败, status={prob.status}")

		return np.asarray(u.value), np.asarray(x.value)


def create_s_path(num_points: int = 260) -> np.ndarray:
	x = np.linspace(0.0, 30.0, num_points)
	y = 2.0 * np.sin(0.35 * x)

	dx = np.gradient(x)
	dy = np.gradient(y)
	yaw = np.arctan2(dy, dx)
	v_ref = np.full_like(x, 1.6)

	return np.vstack((x, y, yaw, v_ref)).T


def simulate():
	cfg = MPCConfig()
	mpc = LinearMPC(cfg)

	path = create_s_path()
	path_xy = path[:, :2]

	state = np.array([0.0, -1.5, 0.0, 0.0], dtype=float)

	sim_steps = 360
	goal_tol = 0.35

	traj = [state.copy()]
	controls = []
	target_idx = 0

	u_prev = np.zeros((2, cfg.horizon))

	for _ in range(sim_steps):
		target_idx = nearest_index(path_xy, state[0], state[1], target_idx)
		x_ref = build_reference_trajectory(path, target_idx, cfg.horizon)

		# 将参考控制设为上一时刻解，能改善数值收敛
		u_ref = u_prev.copy()

		# 保持偏航误差连续，避免 -pi / pi 跳变导致优化抖动
		for k in range(cfg.horizon + 1):
			yaw_err = normalize_angle(x_ref[2, k] - state[2])
			x_ref[2, k] = state[2] + yaw_err

		u_opt, _ = mpc.solve(state, x_ref, u_ref)
		a_cmd = float(u_opt[0, 0])
		delta_cmd = float(u_opt[1, 0])

		state = kinematic_step(state, np.array([a_cmd, delta_cmd]), cfg.dt, cfg.wheel_base)
		state[3] = np.clip(state[3], cfg.min_speed, cfg.max_speed)

		traj.append(state.copy())
		controls.append([a_cmd, delta_cmd])
		u_prev[:, :-1] = u_opt[:, 1:]
		u_prev[:, -1] = u_opt[:, -1]

		goal = path[-1, :2]
		if np.hypot(state[0] - goal[0], state[1] - goal[1]) < goal_tol and target_idx >= len(path) - 5:
			break

	traj = np.array(traj)
	controls = np.array(controls)

	t = np.arange(len(traj)) * cfg.dt

	plt.figure(figsize=(11, 5))
	plt.subplot(1, 2, 1)
	plt.plot(path[:, 0], path[:, 1], "--", label="reference")
	plt.plot(traj[:, 0], traj[:, 1], label="mpc tracking")
	plt.axis("equal")
	plt.xlabel("x [m]")
	plt.ylabel("y [m]")
	plt.title("Path Tracking")
	plt.legend()
	plt.grid(True, alpha=0.3)

	plt.subplot(2, 2, 2)
	plt.plot(t, traj[:, 3], label="speed")
	plt.xlabel("t [s]")
	plt.ylabel("v [m/s]")
	plt.grid(True, alpha=0.3)
	plt.legend()

	if len(controls) > 0:
		tc = np.arange(len(controls)) * cfg.dt
		plt.subplot(2, 2, 4)
		plt.plot(tc, np.rad2deg(controls[:, 1]), label="delta [deg]")
		plt.plot(tc, controls[:, 0], label="a [m/s^2]")
		plt.xlabel("t [s]")
		plt.grid(True, alpha=0.3)
		plt.legend()

	plt.tight_layout()
	plt.show()


if __name__ == "__main__":
	simulate()

