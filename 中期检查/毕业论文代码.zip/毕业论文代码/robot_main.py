#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
机器人工作程序整合入口。

模式说明:
- plan: 仅运行黏菌算法路径规划
- mpc: 仅运行 MPC 路径跟踪示例
- sim: 先做黏菌规划，再用 MPC 跟踪规划路径
- hardware: 调用树莓派传感器与电机控制主循环
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import importlib.util
import os
from pathlib import Path
import sys
import time
from types import ModuleType

import matplotlib.pyplot as plt
import numpy as np


ROOT_DIR = Path(__file__).resolve().parent
SENSOR_FILE = ROOT_DIR / "传感器" / "chuanganqi-1.py"
MPC_FILE = ROOT_DIR / "控制算法" / "kongzhi.py"
SMA_FILE = ROOT_DIR / "黏菌算法" / "nianjun.py"


@dataclass(frozen=True)
class RuntimeConfig:
    """统一管理整合流程中的规划与控制参数。"""

    map_width: int = 85
    map_height: int = 55
    obstacle_ratio: float = 0.16
    map_seed: int = 9
    start_xy: tuple[float, float] = (3.0, 4.0)
    goal_xy: tuple[float, float] = (80.0, 50.0)
    max_segments: int = 28
    step_max: float = 8.0
    dt: float = 0.1
    horizon: int = 12
    wheel_base: float = 2.2
    max_speed: float = 4.5
    goal_tolerance: float = 1.2
    max_steps: int = 500
    v_ref: float = 1.6
    control_timeout_s: float = 0.8
    hardware_pwm_scale: float = 22.0


class BaseChassis:
    """底盘接口抽象：后续可替换为串口/CAN 实机底盘实现。"""

    def get_state(self) -> np.ndarray:
        raise NotImplementedError

    def apply_control(self, a_cmd: float, delta_cmd: float) -> np.ndarray:
        raise NotImplementedError

    def stop(self) -> None:
        raise NotImplementedError


class SimulatedChassis(BaseChassis):
    def __init__(self, mpc_module: ModuleType, mpc_cfg, initial_state: np.ndarray):
        self._mpc = mpc_module
        self._cfg = mpc_cfg
        self._state = initial_state.astype(float).copy()

    def get_state(self) -> np.ndarray:
        return self._state.copy()

    def apply_control(self, a_cmd: float, delta_cmd: float) -> np.ndarray:
        u = np.array([a_cmd, delta_cmd], dtype=float)
        self._state = self._mpc.kinematic_step(self._state, u, self._cfg.dt, self._cfg.wheel_base)
        self._state[3] = np.clip(self._state[3], self._cfg.min_speed, self._cfg.max_speed)
        return self.get_state()

    def stop(self) -> None:
        self._state[3] = 0.0


class HardwareChassis(BaseChassis):
    """硬件底盘实现：调用传感器模块中的电机接口，并维护估计状态。"""

    def __init__(self, sensor_module: ModuleType, mpc_module: ModuleType, mpc_cfg, initial_state: np.ndarray, pwm_scale: float):
        self._sensor = sensor_module
        self._mpc = mpc_module
        self._cfg = mpc_cfg
        self._state = initial_state.astype(float).copy()
        self._pwm_scale = float(pwm_scale)
        self._max_steer_rad = np.deg2rad(30.0)

    def get_state(self) -> np.ndarray:
        return self._state.copy()

    def apply_control(self, a_cmd: float, delta_cmd: float) -> np.ndarray:
        u = np.array([a_cmd, delta_cmd], dtype=float)
        self._state = self._mpc.kinematic_step(self._state, u, self._cfg.dt, self._cfg.wheel_base)
        self._state[3] = np.clip(self._state[3], self._cfg.min_speed, self._cfg.max_speed)

        v_cmd = float(self._state[3])
        steer_ratio = float(np.clip(delta_cmd / self._max_steer_rad, -1.0, 1.0))

        base_pwm = float(np.clip(abs(v_cmd) * self._pwm_scale, 0.0, 100.0))
        turn_pwm = base_pwm * 0.45 * steer_ratio
        left_pwm = float(np.clip(base_pwm - turn_pwm, 0.0, 100.0))
        right_pwm = float(np.clip(base_pwm + turn_pwm, 0.0, 100.0))
        is_forward = v_cmd >= 0.0

        if not hasattr(self._sensor, "set_motor"):
            raise AttributeError("传感器模块缺少 set_motor()，无法执行 MPC 硬件控制")

        self._sensor.set_motor(left_pwm, right_pwm, left_forward=is_forward, right_forward=is_forward)
        return self.get_state()

    def stop(self) -> None:
        if hasattr(self._sensor, "stop"):
            self._sensor.stop()


def build_runtime_config(v_ref: float) -> RuntimeConfig:
    return RuntimeConfig(v_ref=v_ref)


def run_tracking_loop(path: np.ndarray, mpc: ModuleType, controller, cfg, chassis: BaseChassis, runtime_cfg: RuntimeConfig) -> tuple[np.ndarray, np.ndarray]:
    state = chassis.get_state()
    traj = [state.copy()]
    controls = []
    target_idx = 0
    u_prev = np.zeros((2, cfg.horizon))
    last_ok_ts = time.monotonic()

    for _ in range(runtime_cfg.max_steps):
        state = chassis.get_state()
        target_idx = mpc.nearest_index(path[:, :2], state[0], state[1], target_idx)
        x_ref = mpc.build_reference_trajectory(path, target_idx, cfg.horizon)
        u_ref = u_prev.copy()

        for k in range(cfg.horizon + 1):
            yaw_err = mpc.normalize_angle(x_ref[2, k] - state[2])
            x_ref[2, k] = state[2] + yaw_err

        u_opt, _ = controller.solve(state, x_ref, u_ref)
        a_cmd = float(u_opt[0, 0])
        delta_cmd = float(u_opt[1, 0])

        try:
            state = chassis.apply_control(a_cmd=a_cmd, delta_cmd=delta_cmd)
            last_ok_ts = time.monotonic()
        except Exception as exc:
            chassis.stop()
            raise RuntimeError("底盘控制执行失败，已触发停车保护") from exc

        if time.monotonic() - last_ok_ts > runtime_cfg.control_timeout_s:
            chassis.stop()
            raise TimeoutError("底盘控制超时，已触发停车保护")

        traj.append(state.copy())
        controls.append([a_cmd, delta_cmd])

        u_prev[:, :-1] = u_opt[:, 1:]
        u_prev[:, -1] = u_opt[:, -1]

        if np.linalg.norm(state[:2] - path[-1, :2]) < runtime_cfg.goal_tolerance and target_idx >= len(path) - 3:
            chassis.stop()
            break

    return np.asarray(traj), np.asarray(controls)


def load_module(module_name: str, file_path: Path) -> ModuleType:
    if not file_path.exists():
        raise FileNotFoundError(f"未找到模块文件: {file_path}")

    spec = importlib.util.spec_from_file_location(module_name, str(file_path))
    if spec is None or spec.loader is None:
        raise ImportError(f"无法加载模块: {file_path}")

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def waypoints_to_mpc_path(path_xy: np.ndarray, v_ref: float = 1.4) -> np.ndarray:
    """将二维路径点转换为 MPC 所需 [x, y, yaw, v] 格式。"""
    if len(path_xy) < 2:
        raise ValueError("路径点数量不足，无法构建 MPC 参考轨迹")

    x = path_xy[:, 0]
    y = path_xy[:, 1]
    dx = np.gradient(x)
    dy = np.gradient(y)
    yaw = np.arctan2(dy, dx)
    v = np.full_like(x, v_ref, dtype=float)

    return np.vstack((x, y, yaw, v)).T


def run_plan_only(seed: int) -> np.ndarray:
    sma = load_module("sma_module", SMA_FILE)

    grid = sma.build_occupancy_grid(width=85, height=55, obstacle_ratio=0.16, seed=9)
    start = np.array([3.0, 4.0])
    goal = np.array([80.0, 50.0])

    grid[int(start[1]) - 1 : int(start[1]) + 2, int(start[0]) - 1 : int(start[0]) + 2] = 0
    grid[int(goal[1]) - 1 : int(goal[1]) + 2, int(goal[0]) - 1 : int(goal[0]) + 2] = 0

    path = sma.plan_path_sma(grid, start, goal, max_segments=28, step_max=8.0, seed=seed)

    print(f"规划完成，路径点数量: {len(path)}")

    plt.figure(figsize=(9, 6))
    plt.imshow(grid, origin="lower", cmap="gray_r", alpha=0.8)
    plt.plot(path[:, 0], path[:, 1], "-o", lw=1.8, ms=3.5, label="SMA path")
    plt.scatter(start[0], start[1], c="#2a9d8f", s=80, label="Start")
    plt.scatter(goal[0], goal[1], c="#e63946", s=80, label="Goal")
    plt.title("SMA Path Planning")
    plt.xlabel("X")
    plt.ylabel("Y")
    plt.grid(alpha=0.2)
    plt.legend()
    plt.tight_layout()
    plt.show()

    return path


def run_mpc_only() -> None:
    mpc = load_module("mpc_module", MPC_FILE)
    mpc.simulate()


def run_integrated_sim(seed: int, v_ref: float) -> None:
    sma = load_module("sma_module", SMA_FILE)
    mpc = load_module("mpc_module", MPC_FILE)
    runtime_cfg = build_runtime_config(v_ref=v_ref)

    grid = sma.build_occupancy_grid(
        width=runtime_cfg.map_width,
        height=runtime_cfg.map_height,
        obstacle_ratio=runtime_cfg.obstacle_ratio,
        seed=runtime_cfg.map_seed,
    )
    start = np.array(runtime_cfg.start_xy, dtype=float)
    goal = np.array(runtime_cfg.goal_xy, dtype=float)

    grid[int(start[1]) - 1 : int(start[1]) + 2, int(start[0]) - 1 : int(start[0]) + 2] = 0
    grid[int(goal[1]) - 1 : int(goal[1]) + 2, int(goal[0]) - 1 : int(goal[0]) + 2] = 0

    path_xy = sma.plan_path_sma(
        grid,
        start,
        goal,
        max_segments=runtime_cfg.max_segments,
        step_max=runtime_cfg.step_max,
        seed=seed,
    )
    path = waypoints_to_mpc_path(path_xy, v_ref=v_ref)

    cfg = mpc.MPCConfig(
        dt=runtime_cfg.dt,
        horizon=runtime_cfg.horizon,
        wheel_base=runtime_cfg.wheel_base,
        max_speed=runtime_cfg.max_speed,
    )
    controller = mpc.LinearMPC(cfg)

    initial_state = np.array([path[0, 0], path[0, 1], path[0, 2], 0.0], dtype=float)
    chassis: BaseChassis = SimulatedChassis(mpc_module=mpc, mpc_cfg=cfg, initial_state=initial_state)

    traj, controls = run_tracking_loop(path, mpc, controller, cfg, chassis, runtime_cfg)

    print(f"整合仿真完成: 规划点 {len(path)}，跟踪点 {len(traj)}")

    fig = plt.figure(figsize=(12, 5))
    ax1 = fig.add_subplot(1, 2, 1)
    ax1.imshow(grid, origin="lower", cmap="gray_r", alpha=0.65)
    ax1.plot(path[:, 0], path[:, 1], "--", lw=2.0, label="planned path")
    ax1.plot(traj[:, 0], traj[:, 1], lw=2.2, label="MPC tracking")
    ax1.scatter(path[0, 0], path[0, 1], c="#2a9d8f", s=70, label="start")
    ax1.scatter(path[-1, 0], path[-1, 1], c="#e63946", s=70, label="goal")
    ax1.set_title("Integrated Robot Workflow")
    ax1.set_xlabel("X")
    ax1.set_ylabel("Y")
    ax1.grid(alpha=0.2)
    ax1.legend()

    ax2 = fig.add_subplot(2, 2, 2)
    ax2.plot(traj[:, 3], label="speed")
    ax2.set_title("Speed")
    ax2.grid(alpha=0.25)
    ax2.legend()

    ax3 = fig.add_subplot(2, 2, 4)
    if len(controls) > 0:
        ax3.plot(np.rad2deg(controls[:, 1]), label="steer deg")
        ax3.plot(controls[:, 0], label="acc")
    ax3.set_title("Control")
    ax3.grid(alpha=0.25)
    ax3.legend()

    plt.tight_layout()
    plt.show()


def run_integrated_hardware(seed: int, v_ref: float) -> None:
    sma = load_module("sma_module", SMA_FILE)
    mpc = load_module("mpc_module", MPC_FILE)
    sensor = load_module("sensor_module", SENSOR_FILE)
    runtime_cfg = build_runtime_config(v_ref=v_ref)

    grid = sma.build_occupancy_grid(
        width=runtime_cfg.map_width,
        height=runtime_cfg.map_height,
        obstacle_ratio=runtime_cfg.obstacle_ratio,
        seed=runtime_cfg.map_seed,
    )
    start = np.array(runtime_cfg.start_xy, dtype=float)
    goal = np.array(runtime_cfg.goal_xy, dtype=float)

    grid[int(start[1]) - 1 : int(start[1]) + 2, int(start[0]) - 1 : int(start[0]) + 2] = 0
    grid[int(goal[1]) - 1 : int(goal[1]) + 2, int(goal[0]) - 1 : int(goal[0]) + 2] = 0

    path_xy = sma.plan_path_sma(
        grid,
        start,
        goal,
        max_segments=runtime_cfg.max_segments,
        step_max=runtime_cfg.step_max,
        seed=seed,
    )
    path = waypoints_to_mpc_path(path_xy, v_ref=v_ref)

    cfg = mpc.MPCConfig(
        dt=runtime_cfg.dt,
        horizon=runtime_cfg.horizon,
        wheel_base=runtime_cfg.wheel_base,
        max_speed=runtime_cfg.max_speed,
    )
    controller = mpc.LinearMPC(cfg)

    initial_state = np.array([path[0, 0], path[0, 1], path[0, 2], 0.0], dtype=float)
    chassis: BaseChassis = HardwareChassis(
        sensor_module=sensor,
        mpc_module=mpc,
        mpc_cfg=cfg,
        initial_state=initial_state,
        pwm_scale=runtime_cfg.hardware_pwm_scale,
    )

    try:
        traj, _ = run_tracking_loop(path, mpc, controller, cfg, chassis, runtime_cfg)
        print(f"MPC 硬件控制完成: 规划点 {len(path)}，执行点 {len(traj)}")
    except KeyboardInterrupt:
        print("\n手动停止 MPC 硬件控制")
    finally:
        chassis.stop()


def run_hardware(backend: str, seed: int, v_ref: float) -> None:
    if backend == "mpc":
        run_integrated_hardware(seed=seed, v_ref=v_ref)
        return

    sensor = load_module("sensor_module", SENSOR_FILE)
    if not hasattr(sensor, "main"):
        raise AttributeError("传感器模块中未找到 main()")
    sensor.main()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="机器人工作程序整合入口")
    parser.add_argument(
        "--mode",
        type=str,
        default="sim",
        choices=["plan", "mpc", "sim", "hardware"],
        help="运行模式: plan/mpc/sim/hardware",
    )
    parser.add_argument("--seed", type=int, default=18, help="随机种子")
    parser.add_argument("--vref", type=float, default=1.6, help="MPC 参考速度")
    parser.add_argument(
        "--hardware-backend",
        type=str,
        default="legacy",
        choices=["legacy", "mpc"],
        help="hardware 模式后端: legacy(循迹避障) / mpc(MPC 控制)",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    print("=" * 56)
    print(f"机器人工作程序启动 | mode={args.mode}")
    print(f"工程目录: {ROOT_DIR}")
    print("=" * 56)

    if args.mode == "plan":
        run_plan_only(seed=args.seed)
    elif args.mode == "mpc":
        run_mpc_only()
    elif args.mode == "sim":
        run_integrated_sim(seed=args.seed, v_ref=args.vref)
    else:
        run_hardware(backend=args.hardware_backend, seed=args.seed, v_ref=args.vref)


if __name__ == "__main__":
    # 避免部分环境下 matplotlib 后端冲突
    os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
    main()
