import math
from dataclasses import dataclass

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.animation import FuncAnimation


class SlimeMouldOptimizer:
	"""Simple Slime Mould Algorithm (SMA) for continuous optimization."""

	def __init__(self, pop_size=40, max_iter=70, z=0.03, seed=42):
		self.pop_size = pop_size
		self.max_iter = max_iter
		self.z = z
		self.rng = np.random.default_rng(seed)

	def optimize(self, func, lower, upper):
		dim = len(lower)
		lower = np.asarray(lower, dtype=float)
		upper = np.asarray(upper, dtype=float)

		x = self.rng.uniform(lower, upper, size=(self.pop_size, dim))
		fit = np.array([func(v) for v in x])

		best_idx = int(np.argmin(fit))
		best_x = x[best_idx].copy()
		best_f = float(fit[best_idx])

		eps = 1e-12
		for t in range(self.max_iter):
			order = np.argsort(fit)
			x = x[order]
			fit = fit[order]

			if fit[0] < best_f:
				best_f = float(fit[0])
				best_x = x[0].copy()

			worst_f = float(fit[-1])
			s = best_f - worst_f + eps

			w = np.ones_like(x)
			half = self.pop_size // 2
			for i in range(self.pop_size):
				r = self.rng.random(dim)
				if i < half:
					w[i] = 1.0 + r * np.log10((best_f - fit[i]) / s + 1.0 + eps)
				else:
					w[i] = 1.0 - r * np.log10((best_f - fit[i]) / s + 1.0 + eps)

			a = 1.0 - (t + 1) / self.max_iter
			vb = self.rng.uniform(-a, a, size=(self.pop_size, dim))
			vc = self.rng.uniform(-1.0, 1.0, size=(self.pop_size, dim))

			new_x = x.copy()
			for i in range(self.pop_size):
				if self.rng.random() < self.z:
					new_x[i] = self.rng.uniform(lower, upper, size=dim)
					continue

				p = math.tanh(abs(fit[i] - best_f))
				for j in range(dim):
					if self.rng.random() < p:
						a_idx, b_idx = self.rng.integers(0, self.pop_size, size=2)
						new_x[i, j] = best_x[j] + vb[i, j] * (
							w[i, j] * x[a_idx, j] - x[b_idx, j]
						)
					else:
						new_x[i, j] = vc[i, j] * x[i, j]

			x = np.clip(new_x, lower, upper)
			fit = np.array([func(v) for v in x])

		return best_x, best_f


def build_occupancy_grid(width=80, height=50, obstacle_ratio=0.16, seed=7):
	rng = np.random.default_rng(seed)
	grid = np.zeros((height, width), dtype=np.uint8)

	num_rect = int(width * height * obstacle_ratio / 35)
	for _ in range(num_rect):
		w = int(rng.integers(4, 10))
		h = int(rng.integers(4, 10))
		x = int(rng.integers(0, width - w))
		y = int(rng.integers(0, height - h))
		grid[y : y + h, x : x + w] = 1

	return grid


def in_bounds(point, grid):
	x, y = point
	h, w = grid.shape
	return 0 <= x < w and 0 <= y < h


def cell_collision(point, grid):
	x, y = point
	if not in_bounds((x, y), grid):
		return 1.0
	xi = int(np.clip(round(x), 0, grid.shape[1] - 1))
	yi = int(np.clip(round(y), 0, grid.shape[0] - 1))
	return float(grid[yi, xi] == 1)


def line_collision(p1, p2, grid, samples=30):
	for t in np.linspace(0.0, 1.0, samples):
		p = p1 * (1.0 - t) + p2 * t
		if cell_collision(p, grid) > 0.5:
			return 1.0
	return 0.0


def smooth_path(path, grid):
	if len(path) <= 2:
		return path

	smoothed = [path[0]]
	i = 0
	while i < len(path) - 1:
		j = len(path) - 1
		while j > i + 1:
			if line_collision(path[i], path[j], grid) < 0.5:
				break
			j -= 1
		smoothed.append(path[j])
		i = j

	return smoothed


def plan_path_sma(grid, start, goal, max_segments=25, step_max=7.0, seed=42):
	rng = np.random.default_rng(seed)
	optimizer = SlimeMouldOptimizer(pop_size=35, max_iter=65, z=0.04, seed=seed)

	current = np.array(start, dtype=float)
	goal = np.array(goal, dtype=float)
	path = [current.copy()]

	for _ in range(max_segments):
		to_goal = goal - current
		dist_goal = np.linalg.norm(to_goal)
		if dist_goal < 2.0:
			break

		preferred_step = min(step_max, dist_goal)
		center = current + (to_goal / (dist_goal + 1e-9)) * preferred_step

		lower = np.maximum([0.0, 0.0], center - step_max)
		upper = np.minimum([grid.shape[1] - 1.0, grid.shape[0] - 1.0], center + step_max)

		def objective(cand):
			cand = np.asarray(cand, dtype=float)
			step = np.linalg.norm(cand - current)
			collision_now = line_collision(current, cand, grid)
			occ = cell_collision(cand, grid)
			goal_term = np.linalg.norm(goal - cand)
			step_term = abs(step - preferred_step)
			return 2.2 * goal_term + 25.0 * collision_now + 30.0 * occ + 1.4 * step_term

		best, _ = optimizer.optimize(objective, lower, upper)

		if line_collision(current, best, grid) > 0.5 or cell_collision(best, grid) > 0.5:
			# Fallback sampling if SMA result collides.
			candidates = []
			for _ in range(120):
				theta = rng.uniform(-math.pi, math.pi)
				radius = rng.uniform(1.0, step_max)
				cand = current + np.array([math.cos(theta), math.sin(theta)]) * radius
				cand = np.clip(cand, [0.0, 0.0], [grid.shape[1] - 1.0, grid.shape[0] - 1.0])
				if line_collision(current, cand, grid) < 0.5 and cell_collision(cand, grid) < 0.5:
					candidates.append(cand)
			if candidates:
				costs = [np.linalg.norm(goal - c) for c in candidates]
				best = candidates[int(np.argmin(costs))]
			else:
				break

		current = best
		path.append(current.copy())

	path.append(goal.copy())
	path = smooth_path(path, grid)
	return np.array(path)


@dataclass
class CarState:
	x: float
	y: float
	yaw: float
	v: float


def wrap_angle(angle):
	while angle > math.pi:
		angle -= 2.0 * math.pi
	while angle < -math.pi:
		angle += 2.0 * math.pi
	return angle


def find_target_index(state, path, lookahead):
	pos = np.array([state.x, state.y])
	d = np.linalg.norm(path - pos, axis=1)
	idx = int(np.argmin(d))
	while idx < len(path) - 1 and np.linalg.norm(path[idx] - pos) < lookahead:
		idx += 1
	return idx


def simulate_tracking(path, dt=0.1, wheelbase=2.2, target_speed=4.0, max_steps=1800):
	state = CarState(x=float(path[0, 0]), y=float(path[0, 1]), yaw=0.0, v=0.0)
	traj = []
	v_log = []
	steer_log = []

	kp_speed = 1.6
	max_steer = math.radians(35.0)

	for _ in range(max_steps):
		lookahead = 2.5 + 0.3 * state.v
		target_idx = find_target_index(state, path, lookahead)
		target = path[target_idx]

		dx = target[0] - state.x
		dy = target[1] - state.y
		target_yaw = math.atan2(dy, dx)
		alpha = wrap_angle(target_yaw - state.yaw)

		steer = math.atan2(2.0 * wheelbase * math.sin(alpha), lookahead)
		steer = float(np.clip(steer, -max_steer, max_steer))

		acc = kp_speed * (target_speed - state.v)

		state.x += state.v * math.cos(state.yaw) * dt
		state.y += state.v * math.sin(state.yaw) * dt
		state.yaw += (state.v / wheelbase) * math.tan(steer) * dt
		state.yaw = wrap_angle(state.yaw)
		state.v += acc * dt

		traj.append([state.x, state.y])
		v_log.append(state.v)
		steer_log.append(math.degrees(steer))

		if np.linalg.norm(np.array([state.x, state.y]) - path[-1]) < 1.2:
			break

	return np.array(traj), np.array(v_log), np.array(steer_log)


def animate_result(grid, path, traj):
	fig, ax = plt.subplots(figsize=(11, 7))
	ax.imshow(grid, origin="lower", cmap="gray_r", alpha=0.8)

	ax.plot(path[:, 0], path[:, 1], "--", lw=2.0, color="#1d3557", label="SMA path")
	ax.scatter(path[0, 0], path[0, 1], c="#2a9d8f", s=80, label="Start")
	ax.scatter(path[-1, 0], path[-1, 1], c="#e63946", s=80, label="Goal")

	traj_line, = ax.plot([], [], lw=2.5, color="#ff7f11", label="Car trajectory")
	car_dot, = ax.plot([], [], "o", color="#ff7f11", markersize=6)

	ax.set_title("Smart Car Path Planning by Slime Mould Algorithm")
	ax.set_xlabel("X")
	ax.set_ylabel("Y")
	ax.set_xlim(0, grid.shape[1] - 1)
	ax.set_ylim(0, grid.shape[0] - 1)
	ax.legend(loc="upper right")
	ax.grid(alpha=0.2)

	def update(frame):
		traj_line.set_data(traj[: frame + 1, 0], traj[: frame + 1, 1])
		car_dot.set_data([traj[frame, 0]], [traj[frame, 1]])
		return traj_line, car_dot

	FuncAnimation(fig, update, frames=len(traj), interval=35, blit=True, repeat=False)
	plt.tight_layout()
	plt.show()


def main():
	np.random.seed(3)

	grid = build_occupancy_grid(width=85, height=55, obstacle_ratio=0.16, seed=9)
	start = np.array([3.0, 4.0])
	goal = np.array([80.0, 50.0])

	# Keep start and goal free.
	grid[int(start[1]) - 1 : int(start[1]) + 2, int(start[0]) - 1 : int(start[0]) + 2] = 0
	grid[int(goal[1]) - 1 : int(goal[1]) + 2, int(goal[0]) - 1 : int(goal[0]) + 2] = 0

	path = plan_path_sma(grid, start, goal, max_segments=28, step_max=8.0, seed=18)
	traj, speed, steer = simulate_tracking(path, dt=0.1, target_speed=4.2)

	print("Planned waypoints:", len(path))
	print("Tracking points:", len(traj))
	print("Mean speed: %.2f m/s" % np.mean(speed))
	print("Mean steering: %.2f deg" % np.mean(np.abs(steer)))

	animate_result(grid, path, traj)


if __name__ == "__main__":
	main()
